from django.shortcuts import render #importing Django render
from django.template import RequestContext #importing Django template
from django.contrib import messages #importing messages
import pymysql #importing mysql
from django.http import HttpResponse #importing httpResponse

import pandas as pd #importing pandas library
import numpy as np #importing numpy library
import re
from sklearn.feature_extraction.text import TfidfVectorizer #importing Tfidfvectorizer from sklearn
from numpy import dot
from numpy.linalg import norm
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer #importing sentiment analyzer from vader library
from nltk.corpus import stopwords #importing stop words from nltk

stop_words = set(stopwords.words('english')) #using stopwords to take only english words
sid = SentimentIntensityAnalyzer() #intializing sentimentintensityanalyzer model

def getReview(review):
    review_result = "none"
    review = review.lower() #converting reviwes text to lowercase
    review = re.sub('[^A-Za-z]+', ' ', review) #converting uppercase to lower case
    sentiment_dict = sid.polarity_scores(review.strip()) #sentiment strength based on the input text using polarity scores
    compound = sentiment_dict['compound']
    if compound >= 0.05 : 
        review_result = 'Positive' #aassigning positive for score gretaer than 0.05
    return review_result    
    
    
dataset = pd.read_csv("Dataset/amazon_reviews.csv")  #loading the data set
dataset = dataset.values
text = dataset[:,0] ###assigning the input as text
label = dataset[:,1]##target variable
##preprocessing
tfidf_vectorizer = TfidfVectorizer(stop_words=stop_words, use_idf=True, smooth_idf=False, norm=None, decode_error='replace', max_features=1000,lowercase=True)
tfidf = tfidf_vectorizer.fit_transform(text).toarray()    ##converting to array
df = pd.DataFrame(tfidf, columns=tfidf_vectorizer.get_feature_names())
print(df.shape)
df = df.values
X = df[:, 0:1000]

##defining html pages
def index(request):
    if request.method == 'GET':
       return render(request, 'index.html', {})##default loading of html page after entering the url

def Login(request):
    if request.method == 'GET':
       return render(request, 'Login.html', {})##user clicks on login page this is loaded

def Register(request):
    if request.method == 'GET':
       return render(request, 'Register.html', {})##user clicks on Register this html page is loaded

def Recommendation(request):
    if request.method == 'GET':
       return render(request, 'Recommendation.html', {})## recommendation page gets loaded when user clicks for recommendation output

#defining action request
def RecommendationAction(request):
    if request.method == 'POST':
        query = request.POST.get('t1', False) #if the current request from a user enterd the product name,
        test = query.lower().strip() #convertig to lowecase
        test = tfidf_vectorizer.transform([test]).toarray() ##Vector transformation
        test = test[0]
        similarity = 0
        review = 'Unable to get review for recommendation' ## display the review
        rating = 0
        suggestion = "No suggestion available"##display suggestion
        for j in range(len(X)):
            review_score = dot(X[j], test)/(norm(X[j])*norm(test))
            if review_score > similarity:
                similarity = review_score
                review_type = getReview(text[j])
                if review_type == 'Positive':   ##if the review type is positive
                    review = text[j]  #display review
                    rating = label[j]
                    suggestion = "you have chosen best product"  ##display the suggestion
        output="<html><body><center><table border=1><tr><th><font size=3 color=black>Product Name</th>"  ##defining output template with the below names and their output
        output+="<th><font size=3 color=black>Recommended Best Review</th>"
        output+="<th><font size=3 color=black>Recommended Best Rating</th><th><font size=3 color=black>Suggestion</th></tr>"
        output+="<tr><td><font size=3 color=black>"+query+"</td><td><font size=3 color=black>"+review+"</td><td><font size=3 color=black>"+str(rating)+"</td><td><font size=3 color=black>"+suggestion+"</td>"
        #output+"</tr><br/><br/><br/><br/><br/><br/></table>"
        context= {'data':output}
        return render(request, 'Result.html', context)  

        

def Signup(request):  ##signup request
    if request.method == 'POST':
      #user_ip = getClientIP(request)
      #reader = geoip2.database.Reader('C:/Python/PlantDisease/GeoLite2-City.mmdb')
      #response = reader.city('103.48.68.11')
      #print(user_ip)
      #print(response.location.latitude)
      #print(response.location.longitude)
      username = request.POST.get('username', False)## taking username
      password = request.POST.get('password', False)##  taking password
      contact = request.POST.get('contact', False)##  taking contact
      email = request.POST.get('email', False)##  taking email from user
      address = request.POST.get('address', False)##  taking address from user
      ##database connection with host and port
      db_connection = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Recommendation',charset='utf8')
      db_cursor = db_connection.cursor()
      student_sql_query = "INSERT INTO register(username,password,contact,email,address) VALUES('"+username+"','"+password+"','"+contact+"','"+email+"','"+address+"')"
      db_cursor.execute(student_sql_query)
      db_connection.commit()
      print(db_cursor.rowcount, "Record Inserted")
      if db_cursor.rowcount == 1:
       context= {'data':'Signup Process Completed'}
       return render(request, 'Register.html', context)
      else:
       context= {'data':'Error in signup process'}
       return render(request, 'Register.html', context)    
        
def UserLogin(request):##signup request
    if request.method == 'POST':
        username = request.POST.get('username', False)
        password = request.POST.get('password', False)
        utype = 'none'
        con = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'Recommendation',charset='utf8')#starting connection request
        with con:
            cur = con.cursor()
            cur.execute("select * FROM register")
            rows = cur.fetchall()
            for row in rows:
                if row[0] == username and row[1] == password:#matching user details from db and printing the result
                    utype = 'success'
                    break
        if utype == 'success':
            file = open('session.txt','w')
            file.write(username)
            file.close()
            context= {'data':'welcome '+username}
            return render(request, 'UserScreen.html', context)
        if utype == 'none':
            context= {'data':'Invalid login details'}
            return render(request, 'Login.html', context)
    
